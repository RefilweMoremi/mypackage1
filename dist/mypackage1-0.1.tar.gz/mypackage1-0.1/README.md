#PACKAGE-NAME : mypackage1
#This library uses recursion and sorting functions

## Recursion

1.sum_array(array) : Return sum of all items in array

2.fibonacci(n) : Return nth term in fibonacci sequence

3.factorial(n) : Return the factorial of n

4.reverse(word) : Return word in reverse

## sorting

1.bubble_sort(items):Return array of items, sorted in ascending order

2.merge_sort(items): Return array of items, sorted in ascending order

3.quick_sort(items): Return array of items, sorted in ascending order

## Building a python package
'python setup.py sdist'

## Installing this package from github

## Updating this package from githubS
